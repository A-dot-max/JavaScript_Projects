Better example of slider for beGinners
